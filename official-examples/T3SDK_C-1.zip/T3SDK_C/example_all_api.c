/**
 * T3网络验证 C SDK 全部接口调用示例
 * https://www.t3yanzheng.com
 *
 * 演示全部 22 个 API 接口的调用方法
 */

#include <stdio.h>
#include <string.h>
#include "t3sdk/t3sdk.h"

int main() {
    T3Verify verify;
    T3LoginResult login_result;
    T3NoticeResult notice_result;
    T3VersionResult version_result;
    T3QueryResult query_result;
    T3UpdateResult update_result;
    T3CloudDocResult doc_result;
    T3VariableResult var_result;
    T3Result r;
    T3CoreResult core_result;
    T3OnlineResult online_result;
    T3AppSignResult sign_result;
    char machine_code[64];

    /* RSA 算法 + HEX 编码 初始化 */
    if (t3verify_init_rsa(
        &verify,
        "813B2676E9690C89",
        "EC56923E2FD91C99",
        "EA44543183C3F5D3",
        "9AB469F061FA45F4",
        "d633f5e27c1b107cd2a1f98870787263",
        "-----BEGIN PUBLIC KEY-----\n"
        "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDAQP0fmaGhF/sEskSVfDALBG2X\n"
        "KFCtn2HjJj0W+LQOL4bQIyg7Dh1lVUnTSodUwehXGloXHthU/c/Aio7xnYJILewg\n"
        "5QVYKjGbbexgO61KIg0AotYxV8KNUOAg8qPVfsQ+hELwJHAOFHfORSn/fZfd2hVg\n"
        "+YfzVfYS6KW/i0imOQIDAQAB\n"
        "-----END PUBLIC KEY-----"
    ) < 0) {
        printf("初始化失败！\n");
        return 1;
    }

    /* 设置新增接口调用码 */
    t3verify_set_code(&verify, "query", "A2AC50154CC51A76");
    t3verify_set_code(&verify, "register", "6B9EABFF00B80750");
    t3verify_set_code(&verify, "user_login", "ECCFEFE957984480");
    t3verify_set_code(&verify, "user_heartbeat", "EF796F4016C97A66");
    t3verify_set_code(&verify, "qq_login", "B6652EB5C78F0641");
    t3verify_set_code(&verify, "bind_qq", "BF0378334FF0F0F5");
    t3verify_set_code(&verify, "change_password", "B7C4CD0FAE40AE8C");
    t3verify_set_code(&verify, "user_cancel", "A71666D3D237E922");
    t3verify_set_code(&verify, "recharge", "57559AB00DE6A9DE");
    t3verify_set_code(&verify, "kami_recharge", "A4634B5AC1F5341A");
    t3verify_set_code(&verify, "unbind", "2CA5F5986D945633");
    t3verify_set_code(&verify, "ip_unbind", "C21B2219566669B9");
    t3verify_set_code(&verify, "disable", "CF41580160F0AE75");
    t3verify_set_code(&verify, "check_update", "890829CBEFA61A56");
    t3verify_set_code(&verify, "get_variable", "A015ABD9403AC64A");
    t3verify_set_code(&verify, "modify_variable", "78CFB294B32DC2A3");
    t3verify_set_code(&verify, "modify_core", "F9CE457547B9DD0F");
    t3verify_set_code(&verify, "get_kami_core", "8C58C52B3053820A");
    t3verify_set_code(&verify, "get_user_core", "CD79FE55F3CE48B2");
    t3verify_set_code(&verify, "online_kami", "B61D29EBFA5E3CF5");
    t3verify_set_code(&verify, "online_user", "0D46101793B42DD3");
    t3verify_set_code(&verify, "cloud_doc", "F50B362FC86CC38E");
    t3verify_set_code(&verify, "app_sign", "BAB98433A890FFB0");
    t3verify_set_code(&verify, "qq_heartbeat", "77C9731065BAB2A4");
    t3verify_set_code(&verify, "qq_get_variable", "2CE5BD9B12733032");
    t3verify_set_code(&verify, "qq_get_core", "5EF62F8A7630DC9A");
    t3verify_set_code(&verify, "qq_modify_core", "ACA861E2C03E9385");
    t3verify_set_code(&verify, "qq_unbind", "8E113021CB8FE80E");
    t3verify_set_code(&verify, "heartbeat_any", "A0D682FB88F82D31");

    /* 获取本机机器码 */
    get_machine_code(machine_code);

    /* ==================== 1. 获取公告内容 ==================== */
    /* 参数: 无 */
    printf("==================================================\n");
    printf("1. 获取公告内容\n");
    t3verify_get_notice(&verify, &notice_result);
    printf(notice_result.success ? "  公告: %s\n" : "  失败: %s\n",
           notice_result.success ? notice_result.notice : notice_result.error);

    /* ==================== 2. 获取最新版本号 ==================== */
    /* 参数: 无 */
    printf("\n2. 获取最新版本号\n");
    t3verify_get_latest_version(&verify, &version_result);
    printf(version_result.success ? "  最新版本: %s\n" : "  失败: %s\n",
           version_result.success ? version_result.version : version_result.error);

    /* ==================== 3. 检查更新 ==================== */
    /* 参数: ver(当前版本号) */
    const char *ver = "1000";
    printf("\n3. 检查更新\n");
    t3verify_check_update(&verify, ver, &update_result);
    if (update_result.success) {
        printf(update_result.has_update ? "  需要更新!\n" : "  %s\n", update_result.msg);
    } else { printf("  失败: %s\n", update_result.error); }

    /* ==================== 4. 应用签名比对 ==================== */
    /* 参数: autograph(应用签名) */
    const char *autograph = "555";
    printf("\n4. 应用签名比对\n");
    t3verify_app_sign(&verify, autograph, &sign_result);
    if (sign_result.success) {
        printf("  %s\n", sign_result.msg);
        printf("  后台签名: %s\n", sign_result.autograph);
    } else { printf("  失败: %s\n", sign_result.error); }

    /* ==================== 5. 获取云文档 ==================== */
    /* 参数: token(云文档Token) */
    const char *cloud_token = "194db8ba04848ce4a3ba07954086092d";
    printf("\n5. 获取云文档\n");
    t3verify_get_cloud_doc(&verify, cloud_token, &doc_result);
    printf(doc_result.success ? "  云文档内容: %s\n" : "  失败: %s\n",
           doc_result.success ? doc_result.content : doc_result.error);

    /* ==================== 6. 单码卡密登录 ==================== */
    /* 参数: kami(卡密), imei(机器码) */
    const char *card = "Y43495D9E0CEEBAAD095B91999129E96";
    printf("\n6. 单码卡密登录\n");
    t3verify_login(&verify, card, machine_code, &login_result);
    if (login_result.success) {
        printf("  登录成功\n  卡密ID: %s\n  到期时间: %s\n", login_result.id, login_result.end_time);
        printf("  卡密时长: %s\n  剩余时间: %s秒\n", login_result.recharge, login_result.available);
        printf("  绑定设备: %s\n", strlen(login_result.imei) ? login_result.imei : "无");
        printf("  解绑次数: %s\n  核心数据: %s\n", login_result.change, login_result.core);

        /* ==================== 7. 单码心跳验证 ==================== */
        /* 参数: kami(卡密), statecode(登录返回的状态码) */
        printf("\n7. 单码心跳验证\n");
        t3verify_heartbeat(&verify, card, login_result.statecode, &r);
        printf(r.success ? "  心跳验证成功！\n" : "  失败: %s\n", r.error);
    } else { printf("  登录失败: %s\n", login_result.error); }

    /* ==================== 8. 查询卡密状态信息 ==================== */
    /* 参数: kami(卡密) */
    printf("\n8. 查询卡密状态信息\n");
    t3verify_query_kami(&verify, card, &query_result);
    if (query_result.success) {
        printf("  卡密状态: %s\n  激活状态: %s\n", query_result.state, query_result.use);
        printf("  卡密ID: %s\n  使用时间: %s\n", query_result.id, query_result.use_time);
        printf("  到期时间: %s\n  最后在线: %s\n", query_result.end_time, query_result.line_time);
        printf("  在线状态: %s\n  卡密时长: %s\n", query_result.line, query_result.amount);
        printf("  剩余时间: %s秒\n", query_result.available);
    } else { printf("  查询失败: %s\n", query_result.error); }

    /* ==================== 9. 单码解绑设备 ==================== */
    /* 参数: kami(卡密), imei(机器码) */
    printf("\n9. 单码解绑设备\n");
    t3verify_unbind_kami(&verify, card, machine_code, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 10. 单码 IP 解绑 ==================== */
    /* 参数: kami(卡密) */
    printf("\n10. 单码 IP 解绑\n");
    t3verify_ip_unbind_kami(&verify, card, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 11. 通过卡密获取变量 ==================== */
    /* 参数: kami(卡密), valueid(变量ID), valuename(变量名称) */
    const char *valueid = "3660";
    const char *valuename = "demo12345";
    printf("\n11. 通过卡密获取变量\n");
    t3verify_get_variable_by_kami(&verify, card, valueid, valuename, &var_result);
    if (var_result.success) {
        char new_value[1024];
        printf("  变量值: %s\n", var_result.value);

        /* ==================== 12. 通过卡密修改变量 ==================== */
        /* 参数: kami(卡密), valueid(变量ID), valuecontent(变量新内容) */
        snprintf(new_value, sizeof(new_value), "%shello world", var_result.value);
        printf("\n12. 通过卡密修改变量\n");
        t3verify_modify_variable_by_kami(&verify, card, valueid, new_value, &r);
        printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);
    } else { printf("  失败: %s\n", var_result.error); }

    /* ==================== 13. 通过卡密修改核心数据 ==================== */
    /* 参数: kami(卡密), core(核心数据) */
    const char *core_data = "core666";
    printf("\n13. 通过卡密修改核心数据\n");
    t3verify_modify_core_by_kami(&verify, card, core_data, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 14. 获取卡密核心数据 ==================== */
    /* 参数: kami(卡密) */
    printf("\n14. 获取卡密核心数据\n");
    t3verify_get_core_by_kami(&verify, card, &core_result);
    printf(core_result.success ? "  核心数据(Hex): %s\n" : "  失败: %s\n",
           core_result.success ? core_result.core : core_result.error);

    /* ==================== 15. 获取在线卡密数量 ==================== */
    /* 参数: 无 */
    printf("\n15. 获取在线卡密数量\n");
    t3verify_get_online_kami_count(&verify, &online_result);
    if (online_result.success) printf("  当前在线卡密: %d\n", online_result.count);
    else printf("  获取失败: %s\n", online_result.error);

    /* ==================== 16. 禁用卡密 ==================== */
    /* 参数: kami(卡密) */
    /* printf("\n14. 禁用卡密\n"); */
    /* t3verify_disable_kami(&verify, card, &r); */
    /* printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error); */

    /* ==================== 用户体系测试 ==================== */
    printf("\n==================================================\n");
    printf("用户体系测试\n");
    printf("==================================================\n");

    /* ==================== 15. 用户注册 ==================== */
    /* 参数: user(用户名), pass(密码), email(邮箱, 可选) */
    const char *username = "demotest01";
    const char *password = "demotest02";
    const char *email = "demo@example.com";
    printf("\n15. 用户注册\n");
    t3verify_user_register(&verify, username, password, email, &r);
    printf(r.success ? "  %s\n" : "  注册失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 16. 用户充值 ==================== */
    /* 参数: user(用户名), card(充值卡密) */
    const char *recharge_card = "1vjurp5weynkzus5";
    printf("\n16. 用户充值\n");
    t3verify_recharge(&verify, username, recharge_card, &r);
    printf(r.success ? "  %s\n" : "  充值失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 16b. 单码以卡充卡 (type=27) ==================== */
    /* 参数: target_kami(被充卡密, 已激活), source_kami(充值卡密, 未激活) */
    const char *kami_recharge_target = "Y43495D9E0CEEBAAD095B91999129E96";
    const char *kami_recharge_source = "1vjurp5weynkzus5";
    printf("\n16b. 单码以卡充卡\n");
    t3verify_kami_recharge(&verify, kami_recharge_target, kami_recharge_source, &r);
    printf(r.success ? "  %s\n" : "  以卡充卡失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 17. 用户登录 ==================== */
    /* 参数: user(用户名), pass(密码), imei(机器码) */
    printf("\n17. 用户登录\n");
    t3verify_user_login(&verify, username, password, machine_code, &login_result);
    if (login_result.success) {
        printf("  登录成功\n  用户ID: %s\n  到期时间: %s\n", login_result.id, login_result.end_time);
        printf("  充值次数: %s\n  激活时间: %s\n", login_result.recharge, login_result.use_time);
        printf("  绑定设备: %s\n", strlen(login_result.imei) ? login_result.imei : "无");
        printf("  解绑次数: %s\n  核心数据: %s\n", login_result.change, login_result.core);

        /* ==================== 18. 用户心跳验证 ==================== */
        /* 参数: user(用户名), pass(密码), statecode(登录返回的状态码) */
        printf("\n18. 用户心跳验证\n");
        t3verify_user_heartbeat(&verify, username, password, login_result.statecode, &r);
        printf(r.success ? "  心跳验证成功！\n" : "  失败: %s\n", r.error);
    } else { printf("  登录失败: %s\n", login_result.error); }

    /* ==================== 19. 用户绑定QQ ==================== */
    /* 参数: user(用户名), pass(密码), openid(QQ openid), access_token(QQ access_token) */
    const char *openid = "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6";
    const char *access_token = "d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1";
    printf("\n19. 用户绑定QQ\n");
    t3verify_bind_qq(&verify, username, password, openid, access_token, &r);
    printf(r.success ? "  %s\n" : "  绑定失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 20. 用户QQ登录 ==================== */
    /* 参数: openid(QQ openid), access_token(QQ access_token) */
    printf("\n20. 用户QQ登录\n");
    t3verify_qq_login(&verify, openid, access_token, &login_result);
    if (login_result.success) {
        printf("  QQ登录成功\n  用户ID: %s\n  到期时间: %s\n", login_result.id, login_result.end_time);
        printf("  充值次数: %s\n  解绑次数: %s\n  核心数据: %s\n", login_result.recharge, login_result.change, login_result.core);
    } else { printf("  QQ登录失败: %s\n", login_result.error); }

    /* ==================== 21. 用户解绑设备 ==================== */
    /* 参数: user(用户名), pass(密码), imei(机器码) */
    printf("\n21. 用户解绑设备\n");
    t3verify_unbind_user(&verify, username, password, machine_code, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 22. 用户 IP 解绑 ==================== */
    /* 参数: user(用户名), pass(密码) */
    printf("\n22. 用户 IP 解绑\n");
    t3verify_ip_unbind_user(&verify, username, password, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 23. 通过用户获取变量 ==================== */
    /* 参数: user(用户名), pass(密码), valueid(变量ID), valuename(变量名称) */
    printf("\n23. 通过用户获取变量\n");
    t3verify_get_variable_by_user(&verify, username, password, valueid, valuename, &var_result);
    if (var_result.success) {
        char new_value2[1024];
        printf("  变量值: %s\n", var_result.value);

        /* ==================== 24. 通过用户修改变量 ==================== */
        /* 参数: user(用户名), pass(密码), valueid(变量ID), valuecontent(变量新内容) */
        snprintf(new_value2, sizeof(new_value2), "%shello world", var_result.value);
        printf("\n24. 通过用户修改变量\n");
        t3verify_modify_variable_by_user(&verify, username, password, valueid, new_value2, &r);
        printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);
    } else { printf("  失败: %s\n", var_result.error); }

    /* ==================== 25. 通过用户修改核心数据 ==================== */
    /* 参数: user(用户名), pass(密码), core(核心数据) */
    printf("\n25. 通过用户修改核心数据\n");
    t3verify_modify_core_by_user(&verify, username, password, core_data, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 29. 获取用户核心数据 ==================== */
    /* 参数: user(用户名), pass(密码) */
    printf("\n29. 获取用户核心数据\n");
    t3verify_get_core_by_user(&verify, username, password, &core_result);
    printf(core_result.success ? "  核心数据(Hex): %s\n" : "  失败: %s\n",
           core_result.success ? core_result.core : core_result.error);

    /* ==================== 30. 获取在线用户数量 ==================== */
    /* 参数: 无 */
    printf("\n30. 获取在线用户数量\n");
    t3verify_get_online_user_count(&verify, &online_result);
    if (online_result.success) printf("  当前在线用户: %d\n", online_result.count);
    else printf("  获取失败: %s\n", online_result.error);

    /* ==================== 26. 用户修改密码 ==================== */
    /* 参数: user(用户名), oldpass(旧密码), newpass(新密码) */
    const char *new_password = "demo_newpass01";
    printf("\n26. 用户修改密码\n");
    t3verify_change_password(&verify, username, password, new_password, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 27. 禁用用户 ==================== */
    /* 参数: user(用户名), pass(密码) */
    /* printf("\n27. 禁用用户\n"); */
    /* t3verify_disable_user(&verify, username, new_password, &r); */
    /* printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error); */

    /* ==================== 28. 用户注销 ==================== */
    /* 参数: user(用户名), pass(密码) */
    printf("\n28. 用户注销\n");
    t3verify_user_cancel(&verify, username, new_password, &r);
    printf(r.success ? "  %s\n" : "  注销失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== QQ 凭证接口 & 统一心跳 ==================== */
    printf("\n==================================================\n");
    printf("QQ 凭证接口 & 统一心跳\n");
    printf("==================================================\n");

    /* ==================== 31. QQ凭证获取变量 ==================== */
    /* 参数: openid, access_token, valueid, valuename */
    printf("\n31. QQ凭证获取变量\n");
    t3verify_get_variable_by_qq(&verify, openid, access_token, valueid, valuename, &var_result);
    if (var_result.success) printf("  变量值: %s\n", var_result.value);
    else printf("  失败: %s\n", var_result.error);

    /* ==================== 32. QQ凭证心跳 ==================== */
    /* 参数: openid, access_token, statecode(QQ登录返回的状态码) */
    printf("\n32. QQ凭证心跳\n");
    t3verify_qq_heartbeat(&verify, openid, access_token, login_result.statecode, &r);
    printf(r.success ? "  QQ心跳验证成功！\n" : "  失败: %s\n", r.error);

    /* ==================== 33. QQ凭证获取核心数据 ==================== */
    /* 参数: openid, access_token */
    printf("\n33. QQ凭证获取核心数据\n");
    t3verify_get_user_core_by_qq(&verify, openid, access_token, &core_result);
    printf(core_result.success ? "  核心数据(Hex): %s\n" : "  失败: %s\n",
           core_result.success ? core_result.core : core_result.error);

    /* ==================== 34. QQ凭证修改核心数据 ==================== */
    /* 参数: openid, access_token, core */
    printf("\n34. QQ凭证修改核心数据\n");
    t3verify_modify_user_core_by_qq(&verify, openid, access_token, core_data, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 35. 用户解绑QQ ==================== */
    /* 参数: user(用户名), pass(密码) */
    printf("\n35. 用户解绑QQ\n");
    t3verify_unbind_qq(&verify, username, password, &r);
    printf(r.success ? "  %s\n" : "  失败: %s\n", r.success ? r.msg : r.error);

    /* ==================== 36. 统一心跳 ==================== */
    /* 参数: statecode(登录返回的状态码,自动识别单码/用户/QQ) */
    printf("\n36. 统一心跳\n");
    t3verify_heartbeat_any(&verify, login_result.statecode, &r);
    printf(r.success ? "  统一心跳验证成功！\n" : "  失败: %s\n", r.error);

    printf("\n==================================================\n");
    printf("全部接口测试完成！\n");

    return 0;
}
