#include "weiyan/Util.h"
#include <cstdlib>
#include <csignal>
#include <ctime>
#include <chrono>

int main(){


    // 微验接口域名
	const string p0827e6a6bf = "wy.llua.cn";
	// 当前版本，用于检查更新
	const string currentVersion = "1.0";
	// 卡密存储路径
	const string kmPath = "/sdcard/.km";
	
	// 获取公告
	string notice_data = httppost(p0827e6a6bf,"v2/671c3381301b6f153f4d80ac40035687",e7bfd29a89e(o48f1594684(o48f1594684(e7bfd29a89e(g61719db1b8(c8e4e02d07a(e7bfd29a89e(g61719db1b8("id=ms0mYguHG2G","q77feae6b8446586fb5b7")),"fOrYsXDLKjTzilcw6bn321paIxNBetV95MvohAQq+UZRmu/gCyEH0k874SJFWGdP"),"c5f939f2cfd9fd7c21aec26b60390"))))));
	//try {
		json notice_json_response = json::parse(g61719db1b8(g17197f195d(notice_data),l41673abf53("\x05\x5b\x5f\x5d\x5f\x0f\x08\x59\x0f\x5f\x08\x5b\x5a\x58\x59\x53\x52\x5c\x09\x5f\x0c\x5f\x0b\x59\x58\x5a\x08\x5a\x59\x0f\x52", 31, 106)));
		if (notice_json_response.contains("msg")) {
			std::string gg = notice_json_response["msg"]["app_gg"];
			if (!gg.empty()) {
				std::cout << "公告:\n" << gg << std::endl;
			} else {
				
			}
		} else {
			
		}
	//}
	//catch(const std::exception & e) {
		//std::cerr << "公告获取失败" << e.what() << std::endl;
	//}
	std::cout << std::endl;
	
	// 检查更新
	string ini_data = httppost(p0827e6a6bf,"v2/671c3381301b6f153f4d80ac40035687",e7bfd29a89e(o48f1594684(o48f1594684(e7bfd29a89e(g61719db1b8(c8e4e02d07a(e7bfd29a89e(g61719db1b8("id=9PcyLozlM4Y","q77feae6b8446586fb5b7")),"fOrYsXDLKjTzilcw6bn321paIxNBetV95MvohAQq+UZRmu/gCyEH0k874SJFWGdP"),"c5f939f2cfd9fd7c21aec26b60390"))))));
	//try {
		json ini_json_response = json::parse(g61719db1b8(g17197f195d(ini_data),l41673abf53("\x05\x5b\x5f\x5d\x5f\x0f\x08\x59\x0f\x5f\x08\x5b\x5a\x58\x59\x53\x52\x5c\x09\x5f\x0c\x5f\x0b\x59\x58\x5a\x08\x5a\x59\x0f\x52", 31, 106)));
		if (ini_json_response.contains("msg")) {
			std::string version = ini_json_response["msg"]["version"];
			std::string updateshow = ini_json_response["msg"]["updateshow"];
			std::string updateurl = ini_json_response["msg"]["updateurl"];
			std::string updatemust = ini_json_response["msg"]["updatemust"];
			if (version != currentVersion){
				std::cout << "有新版本:" << std::endl << 	
				             "当前版本:" << currentVersion << std::endl <<
				             "最新版本:" << version << std::endl <<
				             "更新内容:" << updateshow << std::endl <<
				             "更新地址:" << updateurl << std::endl;
				if (updatemust == "y"){
		    	    std::cout << "强制更新，请更新至最新版本后使用！" << std::endl;
		    	    exit(0);
		        }
		    }
		} else {
			std::cerr << "更新解析失败" << std::endl;
		}
	//}
	//catch(const std::exception & e) {
		//std::cerr << "检查更新失败" << e.what() << std::endl;
	//}
	std::cout << std::endl;
	
	// 单码登录
	while(true){
	string t7d0132670d;
	string d8bd692d17b = getIMEI();
	std::cout << "请输入卡密(输入y使用上次登录卡密): ";
    if (!(std::cin >> t7d0132670d)) break;
    
    if (t7d0132670d == "y"){
    	ifstream file(kmPath);
        if (!file.is_open()) {
        	std::cout << "没有获取到上次登录卡密" << std::endl;
            continue;
        }
        getline(file, t7d0132670d);
        file.close();
        std::cout << "使用上次卡密:" << t7d0132670d << std::endl;
    }
    
    std::random_device rd;
    std::mt19937 gen(rd()); // 使用 Mersenne Twister 引擎
    std::uniform_int_distribution<> dist(100000, 999999);
    
    auto now = std::chrono::system_clock::now();
    auto epoch = now.time_since_epoch();
    auto timestamp = std::chrono::duration_cast<std::chrono::seconds>(epoch).count();
    
	string x935d4c522a = std::to_string(timestamp);
	string r30b2844457 = std::to_string(dist(gen));
	string z65d758e359 = x8ac3053976("kami=" + t7d0132670d + "&markcode=" + d8bd692d17b + "&t=" + x935d4c522a + "&"+l41673abf53("\xc0\x81\x87\x8f\x87\x87\xd3\x85\x8e\x8f\x86\x83\x84\x8e\x86\xd7\x85\x8f\xd5\xd2\xd3\x81\x80\x87\x8e\x84\xd7\x81\xd0\x85\xd0\x8f", 32, 182)+"");
	string yc51371b9d6 = httppost(p0827e6a6bf,"v2/671c3381301b6f153f4d80ac40035687",e7bfd29a89e(o48f1594684(o48f1594684(e7bfd29a89e(g61719db1b8(c8e4e02d07a(e7bfd29a89e(g61719db1b8("id=4ooszUNauTB&kami=" + t7d0132670d + "&markcode=" + d8bd692d17b + "&t=" + x935d4c522a + "&sign=" + z65d758e359 + "&value=" + r30b2844457,"q77feae6b8446586fb5b7")),"fOrYsXDLKjTzilcw6bn321paIxNBetV95MvohAQq+UZRmu/gCyEH0k874SJFWGdP"),"c5f939f2cfd9fd7c21aec26b60390"))))));
	//try {
		json json_response = json::parse(g61719db1b8(g17197f195d(xb8a4d9b3a4(xb8a4d9b3a4(g61719db1b8(g17197f195d(yc51371b9d6),"s152f82315f5467e54e94")))),"l522705c8a2c827ff761d8773"));
				if (json_response["yab45d10cdcfdb028840375669da177a2"] != 11242) { std::string wy_msg = json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]; std::cout << wy_msg << std::endl; continue; }
		if (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["w320acd7c83749c2004c25d57ea6ec018"] != "b2d3332a9b71321722421101a2b318c2") continue;
		long wy_t = json_response["m7ede9fa99978d0ac7f83830240403547"];
		long wy_tdiff = wy_t - std::stol(x935d4c522a);
		if (wy_tdiff > 30 || wy_tdiff < -30) {
			std::cout << "设备时间不准\n" << std::endl;
			continue;
		}
		std::string wy_t_str = std::to_string(wy_t);
		long wy_c = json_response["yab45d10cdcfdb028840375669da177a2"];
		std::string wy_c_str = std::to_string(wy_c);
		long wy_id = json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"];
		std::string wy_id_str = std::to_string(wy_id);
		if ((json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["q6704c7537bf2"] != R"wyj(x8ac3053976)wyj"(R"wyj(u712330f2ac)wyj"("l41673abf53("\x9b\xda\xdc\xd4\xdc\xdc\x88\xde\xd5\xd4\xdd\xd8\xdf\xd5\xdd\x8c\xde\xd4\x8e\x89\x88\xda\xdb\xdc\xd5\xdf\x8c\xda\x8b\xde\x8b\xd4", 32, 237)std::to_string((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>())std::to_string((int)json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"].get<double>())"))) && (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["wfe71da0479bd"] != R"wyj(x8ac3053976)wyj"(R"wyj(u712330f2ac)wyj"("x935d4c522astd::to_string((int)json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"].get<double>())"))) && (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ybceae94482323a"] != R"wyj(u712330f2ac)wyj"(R"wyj(u712330f2ac)wyj"("z65d758e359z65d758e359l41673abf53("\x9b\xda\xdc\xd4\xdc\xdc\x88\xde\xd5\xd4\xdd\xd8\xdf\xd5\xdd\x8c\xde\xd4\x8e\x89\x88\xda\xdb\xdc\xd5\xdf\x8c\xda\x8b\xde\x8b\xd4", 32, 237)std::to_string((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>())")))) continue;
		if ((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>() != 11242) continue;
		{
			if (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["u1686821dd22b8b848108aa079f8dab50"] == "single"){
				if ((json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["q6704c7537bf2"] != R"wyj(x8ac3053976)wyj"(R"wyj(u712330f2ac)wyj"("l41673abf53("\x9b\xda\xdc\xd4\xdc\xdc\x88\xde\xd5\xd4\xdd\xd8\xdf\xd5\xdd\x8c\xde\xd4\x8e\x89\x88\xda\xdb\xdc\xd5\xdf\x8c\xda\x8b\xde\x8b\xd4", 32, 237)std::to_string((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>())std::to_string((int)json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"].get<double>())"))) && (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["wfe71da0479bd"] != R"wyj(x8ac3053976)wyj"(R"wyj(u712330f2ac)wyj"("x935d4c522astd::to_string((int)json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"].get<double>())"))) && (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ybceae94482323a"] != R"wyj(u712330f2ac)wyj"(R"wyj(u712330f2ac)wyj"("z65d758e359z65d758e359l41673abf53("\x9b\xda\xdc\xd4\xdc\xdc\x88\xde\xd5\xd4\xdd\xd8\xdf\xd5\xdd\x8c\xde\xd4\x8e\x89\x88\xda\xdb\xdc\xd5\xdf\x8c\xda\x8b\xde\x8b\xd4", 32, 237)std::to_string((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>())")))) continue;
				std::cout << "登录成功，剩余可登录次数：" << json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["c27f13333b755643373328a41fc2c2be1"] << std::endl;
			}else{
				if (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["w320acd7c83749c2004c25d57ea6ec018"] != "b2d3332a9b71321722421101a2b318c2") continue;
				long wy_vip = json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["s88c959deb8c303e8c81faa52ea5d9e87"];
				std::tm tm = *std::localtime(&wy_vip );
				std::stringstream ss;
				ss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
				std::cout << "登录成功，到期时间：" << ss.str() << std::endl;
				signal(SIGALRM, _exit);
				alarm(wy_vip-timestamp);
			}
			if ((json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["q6704c7537bf2"] != R"wyj(x8ac3053976)wyj"(R"wyj(u712330f2ac)wyj"("l41673abf53("\x9b\xda\xdc\xd4\xdc\xdc\x88\xde\xd5\xd4\xdd\xd8\xdf\xd5\xdd\x8c\xde\xd4\x8e\x89\x88\xda\xdb\xdc\xd5\xdf\x8c\xda\x8b\xde\x8b\xd4", 32, 237)std::to_string((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>())std::to_string((int)json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"].get<double>())"))) && (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["wfe71da0479bd"] != R"wyj(x8ac3053976)wyj"(R"wyj(u712330f2ac)wyj"("x935d4c522astd::to_string((int)json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"].get<double>())"))) && (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ybceae94482323a"] != R"wyj(u712330f2ac)wyj"(R"wyj(u712330f2ac)wyj"("z65d758e359z65d758e359l41673abf53("\x9b\xda\xdc\xd4\xdc\xdc\x88\xde\xd5\xd4\xdd\xd8\xdf\xd5\xdd\x8c\xde\xd4\x8e\x89\x88\xda\xdb\xdc\xd5\xdf\x8c\xda\x8b\xde\x8b\xd4", 32, 237)std::to_string((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>())")))) continue;
			ofstream file(kmPath);
			if (file.is_open()) {
				file << t7d0132670d << endl;
				file.close();
			} else {
				cerr << "无法保存卡密到文件: " << kmPath << endl;
			}
			if ((json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["q6704c7537bf2"] != R"wyj(x8ac3053976)wyj"(R"wyj(u712330f2ac)wyj"("l41673abf53("\x9b\xda\xdc\xd4\xdc\xdc\x88\xde\xd5\xd4\xdd\xd8\xdf\xd5\xdd\x8c\xde\xd4\x8e\x89\x88\xda\xdb\xdc\xd5\xdf\x8c\xda\x8b\xde\x8b\xd4", 32, 237)std::to_string((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>())std::to_string((int)json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"].get<double>())"))) && (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["wfe71da0479bd"] != R"wyj(x8ac3053976)wyj"(R"wyj(u712330f2ac)wyj"("x935d4c522astd::to_string((int)json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ie66a556e80e2f031a6f0217c909de76b"].get<double>())"))) && (json_response["d7ae7b0247872bf8e70e25b4c01e5f2b5"]["ybceae94482323a"] != R"wyj(u712330f2ac)wyj"(R"wyj(u712330f2ac)wyj"("z65d758e359z65d758e359l41673abf53("\x9b\xda\xdc\xd4\xdc\xdc\x88\xde\xd5\xd4\xdd\xd8\xdf\xd5\xdd\x8c\xde\xd4\x8e\x89\x88\xda\xdb\xdc\xd5\xdf\x8c\xda\x8b\xde\x8b\xd4", 32, 237)std::to_string((int)json_response["yab45d10cdcfdb028840375669da177a2"].get<double>())")))) continue;
			break;
		}
	//}
	//catch(const std::exception & e) {
		//std::cerr << "登录失败" << e.what() << std::endl;
	//}
	std::cout << std::endl;
	}
	
	    return 0;
}
